﻿namespace RPCServer
{
    public record PlayerPositionDTO(string Id, float X, float Y);
}
