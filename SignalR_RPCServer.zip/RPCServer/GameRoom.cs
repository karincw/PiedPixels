﻿using System.Collections.Concurrent;

namespace RPCServer
{
    public class GameRoom
    {
        public string RoomID { get; init; }

        private readonly ConcurrentDictionary<string, Player> _players = new();

        public GameRoom(string roomID)
        {
            RoomID = roomID;
        }
    }
}
