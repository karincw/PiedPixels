﻿namespace RPCClient
{
    public record PlayerPositionDTO(string Id, float X, float Y);
}
